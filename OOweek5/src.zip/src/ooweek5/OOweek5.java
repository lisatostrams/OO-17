/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooweek5;

/**
 *
 * @author Lisa Tostrams s4386167
 * @author Maurice Swanenberg s4331095
 */
public class OOweek5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main m = new Main(); 
    }
    
}

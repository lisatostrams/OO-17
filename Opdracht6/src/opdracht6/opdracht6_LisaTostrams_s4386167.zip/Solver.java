package opdracht6;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Vector;


/**
 * A class that implements a breadth-first search algorithm
 * for finding the Configurations for which the isSolution predicate holds
 * @author Pieter Koopman, Sjaak Smetsers
 * @version 1.3
 * @date 28-02-2013
 * 
 * Lisa Tostrams s4386167
 */
public class Solver
{
    // A queue for maintaining graphs that are not visited yet.
    Queue<Configuration> toExamine;
    Collection<Configuration> examined;
    Vector<Node> nodes; 

    public Solver(Configuration g) {
        //toExamine = new PriorityQueue<Configuration>();  When i use this, all turns to chaos
        toExamine = new LinkedList<Configuration>();
        nodes = new Vector<Node>(); 
        examined = new HashSet<Configuration>();
        Node first = new Node(null, g);
        nodes.add(first);
       
 
        
    }
    
    /* A skeleton implementation of the solver
     * @return a string representation of the solution
     */
    public String solve () {
        Node f = nodes.get(0);
        Configuration item = (Configuration) f.getItem(); 
        toExamine.add(item);
        
        int current = 0;
        while (! toExamine.isEmpty() ) {
            Configuration next = toExamine.remove();
            f = nodes.get(current);
            examined.add(next);
            if ( next.isSolution() ) {
                nodes.add(new Node(f, next));
                return nodes.get(nodes.size()-1).toString();
            } else {
                
                for ( Configuration succ: next.successors() ) {
                    if(!examined.contains(succ)) {
                    toExamine.add  (succ);
                    nodes.add(new Node(f, succ));
                    }
                }
            }
            current ++;
        }
        return "Failure! No solution found.";
    }
    
}

package opdracht2;

/**
 *
 * @author Lisa Tostrams s4386167
 */
public class Opdracht2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        View view = new View();
        view.runView();
    }
    
}
